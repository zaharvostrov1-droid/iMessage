# iMessage — Android starter (visual refresh)

A native Android / Jetpack Compose demo inspired by the visual language of Apple's Messages app. This is an independent project and is not affiliated with Apple.

## Included
- Refined dark conversation list with a lighter iOS-inspired title hierarchy
- Translucent, softly bordered search field
- Updated avatars, spacing, dividers, and message bubbles
- Create a local demo conversation
- Open a conversation and send local demo messages
- GitHub Actions workflow that builds a debug APK

## Build APK in GitHub
1. Upload the **contents** of this `iMessage` folder to the repository root (not the enclosing folder).
2. Open **Actions** and run **Build iMessage APK** (or push to `main` / `master`).
3. Open the successful workflow run and download the `iMessage-debug-apk` artifact.
4. Extract the downloaded artifact ZIP and install `app-debug.apk`.

## Important limitations
This is a local UI prototype. Messages are held in memory and are not delivered to another person's phone. It does not yet include real accounts, a messaging backend, persistent chat storage, contact syncing, real camera uploads, or voice recording. The camera, call, filter, and microphone controls are visual placeholders. The translucent appearance is created with Compose gradients and borders; it is not Apple's private system Liquid Glass implementation.
