package com.mashix.imessage

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF080A10)
private val Panel = Color(0xFF171D29)
private val Blue = Color(0xFF0A84FF)
private val Muted = Color(0xFF9299A8)
private val Hairline = Color.White.copy(alpha = 0.075f)
private val Glass = Color(0xFF202735).copy(alpha = 0.72f)

data class Chat(val id: Int, val name: String, val preview: String, val time: String, val initials: String, val messages: List<Message>)
data class Message(val text: String, val mine: Boolean, val time: String)

class MainActivity : ComponentActivity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 12, 19)
        window.navigationBarColor = android.graphics.Color.rgb(8, 10, 16)
        window.decorView.systemUiVisibility = 0
        setContent { IMessageApp() }
    }
}

@Composable
fun IMessageApp() {
    var chats by remember {
        mutableStateOf(listOf(
            Chat(1, "Алиса", "Уже иду 💙", "09:41", "А", listOf(Message("Привет! Как дела?", false, "09:38"), Message("Всё хорошо, а у тебя?", true, "09:40"), Message("Уже иду 💙", false, "09:41"))),
            Chat(2, "Маша", "Фотография", "Вчера", "М", listOf(Message("Посмотри, что получилось!", false, "Вчера"))),
            Chat(3, "Избранное", "Заметки и сообщения для себя", "Пн", "♡", listOf(Message("Не забыть купить кофе", true, "Пн")))
        ))
    }
    var selected by remember { mutableStateOf<Int?>(null) }
    var showNew by remember { mutableStateOf(false) }
    val active = chats.firstOrNull { it.id == selected }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Blue,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF111A2A), Color(0xFF090D16), Ink))
            )
        ) {
            if (active == null) {
                ChatsScreen(chats, onOpen = { selected = it }, onNew = { showNew = true })
            } else {
                ConversationScreen(active, onBack = { selected = null }, onSend = { text ->
                    chats = chats.map { chat ->
                        if (chat.id == active.id) chat.copy(
                            preview = text, time = "Сейчас",
                            messages = chat.messages + Message(text, true, "Сейчас")
                        ) else chat
                    }
                })
            }
            if (showNew) {
                var name by remember { mutableStateOf("") }
                AlertDialog(
                    onDismissRequest = { showNew = false },
                    title = { Text("Новое сообщение", fontWeight = FontWeight.SemiBold) },
                    text = {
                        OutlinedTextField(
                            value = name, onValueChange = { name = it },
                            label = { Text("Имя собеседника") }, singleLine = true
                        )
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            if (name.isNotBlank()) {
                                val id = (chats.maxOfOrNull { it.id } ?: 0) + 1
                                chats = listOf(Chat(id, name.trim(), "Новая переписка", "Сейчас", name.trim().take(1).uppercase(), emptyList())) + chats
                                selected = id
                                showNew = false
                            }
                        }) { Text("Создать") }
                    },
                    dismissButton = { TextButton(onClick = { showNew = false }) { Text("Отмена") } },
                    containerColor = Panel
                )
            }
        }
    }
}

@Composable
fun ChatsScreen(chats: List<Chat>, onOpen: (Int) -> Unit, onNew: () -> Unit) {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 22.dp, end = 20.dp, top = 18.dp, bottom = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Сообщения", color = Color.White, fontSize = 35.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp
                )
                Spacer(Modifier.height(2.dp))
                Text("iMessage", color = Muted, fontSize = 14.sp, letterSpacing = 0.1.sp)
            }
            Box(
                Modifier.size(48.dp).shadow(10.dp, CircleShape, ambientColor = Blue.copy(alpha = .25f))
                    .clip(CircleShape).background(Blue).clickable { onNew() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Add, contentDescription = "Новое сообщение", tint = Color.White, modifier = Modifier.size(27.dp))
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp)
                .shadow(12.dp, RoundedCornerShape(20.dp), ambientColor = Color.Black.copy(alpha = .22f))
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF283244).copy(alpha = .82f), Color(0xFF1B2331).copy(alpha = .76f))))
                .border(1.dp, Color.White.copy(alpha = .065f), RoundedCornerShape(20.dp))
                .height(58.dp).padding(horizontal = 15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = Muted, modifier = Modifier.size(23.dp))
            Spacer(Modifier.width(12.dp))
            BasicTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                decorationBox = { inner ->
                    Box {
                        if (query.isEmpty()) Text("Поиск", color = Muted, fontSize = 16.sp)
                        inner()
                    }
                }
            )
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(Color.White.copy(alpha = .055f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.FilterList, contentDescription = "Фильтры", tint = Muted, modifier = Modifier.size(19.dp))
            }
        }

        Spacer(Modifier.height(20.dp))
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            items(chats.filter { it.name.contains(query, true) || it.preview.contains(query, true) }, key = { it.id }) { chat ->
                Row(
                    Modifier.fillMaxWidth().clickable { onOpen(chat.id) }
                        .padding(start = 20.dp, end = 22.dp, top = 12.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(chat.initials, 56)
                    Spacer(Modifier.width(15.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(chat.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                            Text(chat.time, color = Muted.copy(alpha = .9f), fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(5.dp))
                        Text(chat.preview, color = Muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                HorizontalDivider(Modifier.padding(start = 91.dp, end = 22.dp), color = Hairline, thickness = 0.7.dp)
            }
        }
    }
}

@Composable
fun ConversationScreen(chat: Chat, onBack: () -> Unit, onSend: (String) -> Unit) {
    var draft by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Blue) }
            Avatar(chat.initials, 38)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(chat.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text("iMessage", color = Muted, fontSize = 11.sp)
            }
            IconButton(onClick = {}) { Icon(Icons.Default.Call, null, tint = Blue) }
            IconButton(onClick = {}) { Icon(Icons.Default.MoreHoriz, null, tint = Blue) }
        }
        HorizontalDivider(color = Hairline, thickness = 0.7.dp)
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    "iMessage · сквозное шифрование", color = Muted, fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
            items(chat.messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.mine) Arrangement.End else Arrangement.Start) {
                    Column(
                        Modifier.widthIn(max = 290.dp).clip(
                            RoundedCornerShape(
                                topStart = 20.dp, topEnd = 20.dp,
                                bottomStart = if (msg.mine) 20.dp else 6.dp,
                                bottomEnd = if (msg.mine) 6.dp else 20.dp
                            )
                        ).background(if (msg.mine) Blue else Color(0xFF303744))
                            .padding(horizontal = 15.dp, vertical = 10.dp)
                    ) {
                        Text(msg.text, color = Color.White, fontSize = 15.sp)
                        Text(msg.time, color = Color.White.copy(alpha = .65f), fontSize = 10.sp, modifier = Modifier.align(Alignment.End).padding(top = 3.dp))
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Glass)
                .border(1.dp, Color.White.copy(alpha = .07f), RoundedCornerShape(28.dp))
                .padding(horizontal = 7.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {}) { Icon(Icons.Default.Add, null, tint = Muted) }
            BasicTextField(
                value = draft, onValueChange = { draft = it },
                modifier = Modifier.weight(1f),
                maxLines = 4,
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                decorationBox = { inner ->
                    Box {
                        if (draft.isEmpty()) Text("iMessage", color = Muted, fontSize = 15.sp)
                        inner()
                    }
                }
            )
            if (draft.isBlank()) {
                IconButton(onClick = {}) { Icon(Icons.Default.CameraAlt, null, tint = Muted) }
                IconButton(onClick = {}) { Icon(Icons.Default.Mic, null, tint = Muted) }
            } else {
                IconButton(
                    onClick = { onSend(draft.trim()); draft = "" },
                    modifier = Modifier.clip(CircleShape).background(Blue)
                ) { Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.White) }
            }
        }
    }
}

@Composable
fun Avatar(initials: String, size: Int) {
    Box(
        Modifier.size(size.dp).shadow(7.dp, CircleShape, ambientColor = Color(0xFF527BFF).copy(alpha = .22f))
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF5D9BFF), Color(0xFF7560E8), Color(0xFF8B62D6))))
            .border(0.8.dp, Color.White.copy(alpha = .18f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(initials, color = Color.White, fontSize = (size / 2.5).sp, fontWeight = FontWeight.SemiBold)
    }
}
