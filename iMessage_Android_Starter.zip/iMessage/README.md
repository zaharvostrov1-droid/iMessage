# iMessage — Android starter

A native Android / Jetpack Compose starter inspired by the visual language of Apple's Messages app. This is an independent app and is not affiliated with Apple.

## Included in v1
- Dark chat list with search
- Create a local conversation
- Open a conversation and send local demo messages
- iOS-inspired blue/gray bubbles and translucent dark composer styling
- GitHub Actions workflow to build a debug APK

## Build APK in GitHub
1. Create a new GitHub repository.
2. Extract this ZIP on your phone or computer, then upload the **contents** of this folder to the repository root (not the ZIP as one file).
3. Open the repository's **Actions** tab and run **Build iMessage APK** (or push to `main`).
4. Open the completed workflow run and download the `iMessage-debug-apk` artifact.
5. Extract the downloaded artifact and install `app-debug.apk` on your Android phone.

## Important
This first build is a local prototype: messages are stored only in the app's in-memory demo state and are not delivered to another person's phone. Real accounts, cross-device messaging, persistent storage, image upload, and voice recording need a backend and additional implementation. Camera and microphone buttons are visual placeholders in this starter.
