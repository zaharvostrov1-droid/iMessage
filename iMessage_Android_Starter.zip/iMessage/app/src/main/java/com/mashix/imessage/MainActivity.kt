package com.mashix.imessage

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF080B12)
private val Panel = Color(0xFF171D29)
private val Blue = Color(0xFF1685FF)
private val Muted = Color(0xFF929CAB)

 data class Chat(val id: Int, val name: String, val preview: String, val time: String, val initials: String, val messages: List<Message>)
 data class Message(val text: String, val mine: Boolean, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IMessageApp() }
    }
}

@Composable
fun IMessageApp() {
    var chats by remember {
        mutableStateOf(listOf(
            Chat(1, "Алиса", "Уже иду 💙", "09:41", "А", listOf(Message("Привет! Как дела?", false, "09:38"), Message("Всё хорошо, а у тебя?", true, "09:40"), Message("Уже иду 💙", false, "09:41"))),
            Chat(2, "Маша", "Фотография", "Вчера", "М", listOf(Message("Посмотри, что получилось!", false, "Вчера"))),
            Chat(3, "Избранное", "Заметки и сообщения для себя", "Пн", "♡", listOf(Message("Не забыть купить кофе", true, "Пн")))
        ))
    }
    var selected by remember { mutableStateOf<Int?>(null) }
    var showNew by remember { mutableStateOf(false) }
    val active = chats.firstOrNull { it.id == selected }
    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Blue, onBackground = Color.White, onSurface = Color.White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF101827), Ink, Color(0xFF090B10))))) {
            if (active == null) {
                ChatsScreen(chats, onOpen = { selected = it }, onNew = { showNew = true })
            } else {
                ConversationScreen(active, onBack = { selected = null }, onSend = { text ->
                    chats = chats.map { chat -> if (chat.id == active.id) chat.copy(preview = text, time = "Сейчас", messages = chat.messages + Message(text, true, "Сейчас")) else chat }
                })
            }
            if (showNew) {
                var name by remember { mutableStateOf("") }
                AlertDialog(
                    onDismissRequest = { showNew = false },
                    title = { Text("Новое сообщение") },
                    text = { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Имя собеседника") }, singleLine = true) },
                    confirmButton = { TextButton(onClick = { if (name.isNotBlank()) { val id = (chats.maxOfOrNull { it.id } ?: 0) + 1; chats = listOf(Chat(id, name.trim(), "Новая переписка", "Сейчас", name.trim().take(1).uppercase(), emptyList())) + chats; selected = id; showNew = false } }) { Text("Создать") } },
                    dismissButton = { TextButton(onClick = { showNew = false }) { Text("Отмена") } },
                    containerColor = Panel
                )
            }
        }
    }
}

@Composable
fun ChatsScreen(chats: List<Chat>, onOpen: (Int) -> Unit, onNew: () -> Unit) {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Сообщения", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("iMessage", color = Muted, fontSize = 13.sp)
            }
            IconButton(onClick = onNew, modifier = Modifier.size(44.dp).clip(CircleShape).background(Blue)) { Icon(Icons.Default.Add, null, tint = Color.White) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .075f)).padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint = Muted)
            Spacer(Modifier.width(9.dp))
            androidx.compose.material3.TextField(value = query, onValueChange = { query = it }, placeholder = { Text("Поиск", color = Muted) }, singleLine = true, colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Blue), modifier = Modifier.weight(1f))
            Icon(Icons.Default.Tune, null, tint = Muted)
        }
        Spacer(Modifier.height(16.dp))
        LazyColumn(contentPadding = PaddingValues(bottom = 28.dp)) {
            items(chats.filter { it.name.contains(query, true) || it.preview.contains(query, true) }, key = { it.id }) { chat ->
                Row(Modifier.fillMaxWidth().clickable { onOpen(chat.id) }.padding(horizontal = 20.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(chat.initials, 54)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Text(chat.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f)); Text(chat.time, color = Muted, fontSize = 12.sp) }
                        Spacer(Modifier.height(5.dp))
                        Text(chat.preview, color = Muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                HorizontalDivider(Modifier.padding(start = 88.dp, end = 20.dp), color = Color.White.copy(alpha = .07f))
            }
        }
    }
}

@Composable
fun ConversationScreen(chat: Chat, onBack: () -> Unit, onSend: (String) -> Unit) {
    var draft by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Blue) }
            Avatar(chat.initials, 38)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text(chat.name, color = Color.White, fontWeight = FontWeight.SemiBold); Text("iMessage", color = Muted, fontSize = 11.sp) }
            IconButton(onClick = {}) { Icon(Icons.Default.Call, null, tint = Blue) }
            IconButton(onClick = {}) { Icon(Icons.Default.MoreHoriz, null, tint = Blue) }
        }
        HorizontalDivider(color = Color.White.copy(alpha = .07f))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("iMessage · сквозное шифрование", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
            items(chat.messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.mine) Arrangement.End else Arrangement.Start) {
                    Column(Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(20.dp)).background(if (msg.mine) Blue else Color(0xFF303744)).padding(horizontal = 15.dp, vertical = 10.dp)) {
                        Text(msg.text, color = Color.White, fontSize = 15.sp)
                        Text(msg.time, color = Color.White.copy(alpha = .65f), fontSize = 10.sp, modifier = Modifier.align(Alignment.End).padding(top = 3.dp))
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp).clip(RoundedCornerShape(28.dp)).background(Color(0xFF252D3A).copy(alpha = .92f)).padding(horizontal = 7.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {}) { Icon(Icons.Default.Add, null, tint = Muted) }
            androidx.compose.material3.TextField(value = draft, onValueChange = { draft = it }, placeholder = { Text("iMessage", color = Muted) }, modifier = Modifier.weight(1f), maxLines = 4, colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Blue))
            if (draft.isBlank()) {
                IconButton(onClick = {}) { Icon(Icons.Default.CameraAlt, null, tint = Muted) }
                IconButton(onClick = {}) { Icon(Icons.Default.Mic, null, tint = Muted) }
            } else {
                IconButton(onClick = { onSend(draft.trim()); draft = "" }, modifier = Modifier.clip(CircleShape).background(Blue)) { Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.White) }
            }
        }
    }
}

@Composable
fun Avatar(initials: String, size: Int) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF4D91FF), Color(0xFF7656D8)))), contentAlignment = Alignment.Center) {
        Text(initials, color = Color.White, fontSize = (size / 2.5).sp, fontWeight = FontWeight.Bold)
    }
}
